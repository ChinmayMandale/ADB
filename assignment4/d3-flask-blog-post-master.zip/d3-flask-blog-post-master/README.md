# d3-flask-blog-post

## Requirements
* Python3

## Build

To run this in your environment, you can perform the command below in a virtualenv.

```bash
pip3 install -r requirements.txt
python3 app.py
```
